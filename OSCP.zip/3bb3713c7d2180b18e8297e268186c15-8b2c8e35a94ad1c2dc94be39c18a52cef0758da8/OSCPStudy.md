_(Information rovided by @Mod Derek from Security Blue Team Discord from Daniel Durnea on the Offensive Security [Facebook page](https://www.facebook.com/groups/OffSec/) - I am not the original author of this information)_

## How to prepare for OSCP complete guide 

**Below are 5 skills which you have to improve before registering for OSCP**

- Learn basic of Computer Network, Web application, and Linux
- Learn Bash and Python scripting
- Enumeration is key in OSCP lab, I repeat Enumeration is key in OSCP Lab and in real world too
- Download vulnerable VM machines from vulnhub
- Buffer Overflow (BOF) exploitation

**Below are the free reference before registration of OSCP**

https://www.cybrary.it/course/ethical-hacking/

https://www.cybrary.it/course/web-application-pen-testing/

https://www.cybrary.it/course/advanced-penetration-testing/

https://www.offensive-security.com/metasploit-unleashed/

https://www.cybrary.it/course/python/

**Below are the reference for Buffer overflow and exploit developmet for OSCP**
http://www.fuzzysecurity.com/tutorials/expDev/1.html

https://www.corelan.be/index.php/2009/07/19/exploit-writing-tutorial-part-1-stack-based-overflows/

**For Bash Scripting **
http://www.tldp.org/LDP/Bash-Beginners-Guide/html/

**Transferring Files from Linux to Windows & post-exploitation**

https://blog.ropnop.com/transferring-files-from-kali-to-windows/

https://www.cybrary.it/course/post-exploitation-hacking/

**Privilege Escalation:**

http://www.greyhathacker.net/?p=738

http://www.fuzzysecurity.com/tutorials/16.html

https://github.com/GDSSecurity/Windows-Exploit-Suggester

http://pwnwiki.io/#!privesc/windows/index.md

https://blog.g0tmi1k.com/2011/08/basic-linux-privilege-escalation/

https://github.com/rebootuser/LinEnum

https://www.youtube.com/watch?v=PC_iMqiuIRQ

https://www.adampalmer.me/iodigitalsec/2013/08/13/mysql-root-to-system-root-with-udf-for-windows-and-linux/

**Port redirection/tunneling**

https://chamibuddhika.wordpress.com/2012/03/21/ssh-tunnelling-explained/

http://www.abatchy.com/search/label/Networking

**Practice Lab online & offline** 
_Most of this lab help you to understand different attack and (privilege escaltion very very important for OSCP )_

http://overthewire.org/wargames/bandit/

https://www.explainshell.com/

https://www.vulnhub.com/?q=kioptrix&sort=date-asc&type=vm

https://www.vulnhub.com/entry/fristileaks-13,133/

https://www.vulnhub.com/entry/brainpan-1,51/ (Buffer overflow vm)

https://www.vulnhub.com/entry/mr-robot-1,151/

https://www.vulnhub.com/entry/hacklab-vulnix,48/

https://www.vulnhub.com/entry/vulnos-2,147/

https://www.vulnhub.com/entry/sickos-12,144/

https://www.vulnhub.com/entry/devrandom-scream,47/

https://www.vulnhub.com/entry/skytower-1,96/

https://github.com/rapid7/metasploitable3/wiki
